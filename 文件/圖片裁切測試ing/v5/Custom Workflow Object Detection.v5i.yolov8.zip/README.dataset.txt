# Custom Workflow Object Detection > 2025-06-30 12:35am
https://universe.roboflow.com/project-bgdl3/custom-workflow-object-detection-nqeqw

Provided by a Roboflow user
License: CC BY 4.0

